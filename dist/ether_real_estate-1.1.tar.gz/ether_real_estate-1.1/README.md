# The `ether_real_estate` Package

This package simulates commercial real estate transactions over the Ethereum blockchain.