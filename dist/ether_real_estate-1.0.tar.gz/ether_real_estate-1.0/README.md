# *etheR*eal Estate

This package simulates commercial real estate transactions over the Ethereum blockchain.