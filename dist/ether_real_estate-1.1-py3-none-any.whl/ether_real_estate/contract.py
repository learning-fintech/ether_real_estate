class Contract:  # TODO: forbearance agreement subject to verifiable cash flows in the contract
    def __init__(self, rent=5.0, periods=3):
        self.rent = rent
        self.periods = periods
